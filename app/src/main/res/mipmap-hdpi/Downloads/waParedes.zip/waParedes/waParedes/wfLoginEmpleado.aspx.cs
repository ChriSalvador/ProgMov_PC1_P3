﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using waParedes.DAO;

namespace waParedes
{
    public partial class wfLoginEmpleado : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnIngresar_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            DaoEmpleado dao = new DaoEmpleado();
            empleado usu = new empleado();
            usu.usuario = txtUsername.Text.Trim();
            usu.password = txtPassword.Text.Trim();
            dt = dao.iniciarSesion(usu);
            if (dt.Rows.Count == 0)
            {
                lblRespuesta.Text = "Usuario o Password no Válido";
            }
            else
            {
                Response.Redirect("Empleado/Index");
            }
        }
    }
}