﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using waParedes;

namespace waParedes.Controllers
{
    public class TipopagoController : Controller
    {
        private paredes2021Entities db = new paredes2021Entities();

        // GET: Tipopago
        public ActionResult Index()
        {
            return View(db.tipopago.ToList());
        }

        // GET: Tipopago/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tipopago tipopago = db.tipopago.Find(id);
            if (tipopago == null)
            {
                return HttpNotFound();
            }
            return View(tipopago);
        }

        // GET: Tipopago/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Tipopago/Create
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "idtp,metodopago")] tipopago tipopago)
        {
            if (ModelState.IsValid)
            {
                db.tipopago.Add(tipopago);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(tipopago);
        }

        // GET: Tipopago/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tipopago tipopago = db.tipopago.Find(id);
            if (tipopago == null)
            {
                return HttpNotFound();
            }
            return View(tipopago);
        }

        // POST: Tipopago/Edit/5
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "idtp,metodopago")] tipopago tipopago)
        {
            if (ModelState.IsValid)
            {
                db.Entry(tipopago).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(tipopago);
        }

        // GET: Tipopago/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tipopago tipopago = db.tipopago.Find(id);
            if (tipopago == null)
            {
                return HttpNotFound();
            }
            return View(tipopago);
        }

        // POST: Tipopago/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            tipopago tipopago = db.tipopago.Find(id);
            db.tipopago.Remove(tipopago);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
