﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Web.Mvc;
using waParedes;

namespace waParedes.DAO
{
    public class DaoEmpleado
    {
        private SqlConnection conn = new SqlConnection(@"Server=LAPTOP-EK30KCKI; Database=paredes2021; Integrated Security=true;");

        public DataTable iniciarSesion(empleado usu)
        {
            SqlDataAdapter da = new SqlDataAdapter("select usuario, password from empleado where usuario=@user and password=@pass", conn);
            da.SelectCommand.Parameters.AddWithValue("@user", usu.usuario);
            da.SelectCommand.Parameters.AddWithValue("@pass", usu.password);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }
    }
}