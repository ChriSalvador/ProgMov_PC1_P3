﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using waParedes;

namespace waParedes.Controllers
{
    public class ComprobanteController : Controller
    {
        private paredes2021Entities db = new paredes2021Entities();

        // GET: Comprobante
        public ActionResult Index()
        {
            var comprobante = db.comprobante.Include(c => c.cliente).Include(c => c.detallepedido1).Include(c => c.empleado).Include(c => c.tipopago);
            return View(comprobante.ToList());
        }

        // GET: Comprobante/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            comprobante comprobante = db.comprobante.Find(id);
            if (comprobante == null)
            {
                return HttpNotFound();
            }
            return View(comprobante);
        }

        // GET: Comprobante/Create
        public ActionResult Create()
        {
            ViewBag.idcli = new SelectList(db.cliente, "idcli", "nombre");
            ViewBag.detallepedido = new SelectList(db.detallepedido, "detallepedido1", "detallepedido1");
            ViewBag.idemp = new SelectList(db.empleado, "idemp", "nombre");
            ViewBag.idtp = new SelectList(db.tipopago, "idtp", "metodopago");
            return View();
        }

        // POST: Comprobante/Create
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "idcom,descripcion,montoigv,totalneto,preciototal,tipo,idcli,idemp,detallepedido,idtp")] comprobante comprobante)
        {
            if (ModelState.IsValid)
            {
                db.comprobante.Add(comprobante);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.idcli = new SelectList(db.cliente, "idcli", "nombre", comprobante.idcli);
            ViewBag.detallepedido = new SelectList(db.detallepedido, "detallepedido1", "detallepedido1", comprobante.detallepedido);
            ViewBag.idemp = new SelectList(db.empleado, "idemp", "nombre", comprobante.idemp);
            ViewBag.idtp = new SelectList(db.tipopago, "idtp", "metodopago", comprobante.idtp);
            return View(comprobante);
        }

        // GET: Comprobante/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            comprobante comprobante = db.comprobante.Find(id);
            if (comprobante == null)
            {
                return HttpNotFound();
            }
            ViewBag.idcli = new SelectList(db.cliente, "idcli", "nombre", comprobante.idcli);
            ViewBag.detallepedido = new SelectList(db.detallepedido, "detallepedido1", "detallepedido1", comprobante.detallepedido);
            ViewBag.idemp = new SelectList(db.empleado, "idemp", "nombre", comprobante.idemp);
            ViewBag.idtp = new SelectList(db.tipopago, "idtp", "metodopago", comprobante.idtp);
            return View(comprobante);
        }

        // POST: Comprobante/Edit/5
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "idcom,descripcion,montoigv,totalneto,preciototal,tipo,idcli,idemp,detallepedido,idtp")] comprobante comprobante)
        {
            if (ModelState.IsValid)
            {
                db.Entry(comprobante).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.idcli = new SelectList(db.cliente, "idcli", "nombre", comprobante.idcli);
            ViewBag.detallepedido = new SelectList(db.detallepedido, "detallepedido1", "detallepedido1", comprobante.detallepedido);
            ViewBag.idemp = new SelectList(db.empleado, "idemp", "nombre", comprobante.idemp);
            ViewBag.idtp = new SelectList(db.tipopago, "idtp", "metodopago", comprobante.idtp);
            return View(comprobante);
        }

        // GET: Comprobante/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            comprobante comprobante = db.comprobante.Find(id);
            if (comprobante == null)
            {
                return HttpNotFound();
            }
            return View(comprobante);
        }

        // POST: Comprobante/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            comprobante comprobante = db.comprobante.Find(id);
            db.comprobante.Remove(comprobante);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
