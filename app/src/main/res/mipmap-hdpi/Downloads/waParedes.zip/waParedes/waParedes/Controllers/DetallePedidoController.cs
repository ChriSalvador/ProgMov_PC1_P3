﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using waParedes;

namespace waParedes.Controllers
{
    public class DetallePedidoController : Controller
    {
        private paredes2021Entities db = new paredes2021Entities();

        // GET: DetallePedido
        public ActionResult Index()
        {
            var detallepedido = db.detallepedido.Include(d => d.pedido);
            return View(detallepedido.ToList());
        }

        // GET: DetallePedido/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            detallepedido detallepedido = db.detallepedido.Find(id);
            if (detallepedido == null)
            {
                return HttpNotFound();
            }
            return View(detallepedido);
        }

        // GET: DetallePedido/Create
        public ActionResult Create()
        {
            ViewBag.idped = new SelectList(db.pedido, "idped", "numeroorden");
            return View();
        }

        // POST: DetallePedido/Create
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "detallepedido1,punitario,cantidad,idped")] detallepedido detallepedido)
        {
            if (ModelState.IsValid)
            {
                db.detallepedido.Add(detallepedido);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.idped = new SelectList(db.pedido, "idped", "descripcion", detallepedido.pedido.producto.nombre);
            return View(detallepedido);
        }

        // GET: DetallePedido/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            detallepedido detallepedido = db.detallepedido.Find(id);
            if (detallepedido == null)
            {
                return HttpNotFound();
            }
            ViewBag.idped = new SelectList(db.pedido, "idped", "descripcion", detallepedido.idped);
            return View(detallepedido);
        }

        // POST: DetallePedido/Edit/5
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "detallepedido1,punitario,cantidad,idped")] detallepedido detallepedido)
        {
            if (ModelState.IsValid)
            {
                db.Entry(detallepedido).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.idped = new SelectList(db.pedido, "idped", "descripcion", detallepedido.idped);
            return View(detallepedido);
        }

        // GET: DetallePedido/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            detallepedido detallepedido = db.detallepedido.Find(id);
            if (detallepedido == null)
            {
                return HttpNotFound();
            }
            return View(detallepedido);
        }

        // POST: DetallePedido/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            detallepedido detallepedido = db.detallepedido.Find(id);
            db.detallepedido.Remove(detallepedido);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        
    }
}
