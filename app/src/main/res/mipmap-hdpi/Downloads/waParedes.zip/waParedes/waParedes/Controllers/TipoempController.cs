﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using waParedes;

namespace waParedes.Controllers
{
    public class TipoempController : Controller
    {
        private paredes2021Entities db = new paredes2021Entities();

        // GET: Tipoemp
        public ActionResult Index()
        {
            return View(db.tipoemp.ToList());
        }

        // GET: Tipoemp/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tipoemp tipoemp = db.tipoemp.Find(id);
            if (tipoemp == null)
            {
                return HttpNotFound();
            }
            return View(tipoemp);
        }

        // GET: Tipoemp/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Tipoemp/Create
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "idte,cargo")] tipoemp tipoemp)
        {
            if (ModelState.IsValid)
            {
                db.tipoemp.Add(tipoemp);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(tipoemp);
        }

        // GET: Tipoemp/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tipoemp tipoemp = db.tipoemp.Find(id);
            if (tipoemp == null)
            {
                return HttpNotFound();
            }
            return View(tipoemp);
        }

        // POST: Tipoemp/Edit/5
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "idte,cargo")] tipoemp tipoemp)
        {
            if (ModelState.IsValid)
            {
                db.Entry(tipoemp).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(tipoemp);
        }

        // GET: Tipoemp/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tipoemp tipoemp = db.tipoemp.Find(id);
            if (tipoemp == null)
            {
                return HttpNotFound();
            }
            return View(tipoemp);
        }

        // POST: Tipoemp/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            tipoemp tipoemp = db.tipoemp.Find(id);
            db.tipoemp.Remove(tipoemp);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
